export const RHYTHM = '2rem';
export const weight = {
  BOLD: '700',
  MEDIUM: '500',
  NORMAL: '400',
  LIGHT: '300',
};
export const size = {
  SMALL: '0.75rem',
};
